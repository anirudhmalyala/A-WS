document.write("Anii Mal");

function replaceParaText(){
document.getElementById('para1').innerHTML="hi, Anii";
}

function doSum(){
var x=document.getElementById("fv").value;
var y=document.getElementById("sv").value;
var p= parseInt(x) + parseInt(y);
var s= parseInt(x) - parseInt(y);
document.write("Sum is:	"+p);
<br>
document.write("Sum is:	"+s);
}