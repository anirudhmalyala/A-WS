function doSum(){
var x=document.getElementById("fv").value;
var y=document.getElementById("sv").value;
var p= parseInt(x) + parseInt(y);
document.write("Sum is:	"+p);
}
function doSub(){
var x=document.getElementById("fv").value;
var y=document.getElementById("sv").value;
var s= parseInt(x) - parseInt(y);
document.write("Sub is:	"+s);
}