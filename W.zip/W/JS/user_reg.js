function validate() {
    var a = document.getElementById("UserName").value;
    var b = document.getElementById("EmailID").value;
    var c = document.getElementById("Password").value;
    var d = document.getElementById("CPassword").value;
    var e = document.getElementById("MobileNumber").value;
    var f = /^[a-zA-Z0-9]{6,15}$/; //a
    var g = /^[a-zA-Z0-9]+[@][0-9a-zA-Z]+[.][a-zA-Z]+$/; //b
    var h = /^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z]).{6,15}$/;//c
    var i = /^[6-9][0-9]{9}$/; //e
    
    if(a.match(f)){
            document.getElementById('Uerror').innerHTML="";
            }
            else{
            document.getElementById('Uerror').innerHTML="<b style='color:red'>Invalid Name</b>";
            }
            if(b.match(g)){
                document.getElementById('Eerror').innerHTML="";
                }
                else{
                document.getElementById('Eerror').innerHTML="<b style='color:red'>Invalid Email</b>";
        }
        if(c.match(h)){
            document.getElementById('Perror').innerHTML="";
            }
            else{
            document.getElementById('Perror').innerHTML="<b style='color:red'>Invalid Password</b>";
    }
        if(e.match(i)){
            document.getElementById('Merror').innerHTML="";
        }
            else{ 
            document.getElementById('Merror').innerHTML="<b style='color:red'>Invalid Mobile Number</b>";
    }

    function newFunction() {
        if (c == d) {
            document.getElementById('Cerror').innerHTML = "<b style='color:green'>Password Matched</b>";
        }
        else {
            document.getElementById('Cerror').innerHTML = "<b style='color:red'>Invalid Password</b>";
        }
    }
}

