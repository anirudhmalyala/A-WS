window.onload = function(){
    document.getElementById('send').onclick = function(e){
        var a = document.getElementById("ID").value;
        var b = document.getElementById("Name").value;
        var c = document.getElementById("EmailID").value;
        var d = document.getElementById("Quantity").value;
        if(d<=100){
            d=d*2.96;
        }
        else{
            d=d*5.56;
    }
        if(a!="" && b!="" && c!="" && d!=""){
            alert("Customer ID: "+a+"\nName: "+b+"\nEmail ID: "+c+"\nNo.of Units: "+d);        
    
        }
 }
}

 